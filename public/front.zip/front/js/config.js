/**
 * Created by Administrator on 2018/4/14 0014.
 */
require.config({
  baseUrl:'/front/',
  paths:{
    template:'./lib/artTemplate/template-web',
    mui:'./lib/mui/js/mui',
    zepto:'./lib/zepto/zepto'
  }

})